﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;
using BUSINESS_OBJECT;
namespace reg
{
    public partial class WebForm16 : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            register_object ro = new register_object();
            ro.name = TextBox1.Text;
            ro.phone = TextBox2.Text;
            ro.email = TextBox3.Text;
            ro.password = TextBox4.Text;
            ro.country = TextBox6.Text;
            ro.city = TextBox7.Text;
            ro.pincode = TextBox8.Text;
            ro.securityquestion = DropDownList1.SelectedValue;
            ro.securityanswer = TextBox9.Text;
            ro.balance = "40000";
            register_bal cb = new register_bal();
            string msg = cb.insertcustomer(ro);
            if (!msg.Equals("Success"))
            {
                Label11.Visible = true;
               Label11.Text = "Registration Sucessful";
                
            }

            else
            {

                Label11.Text = "Unsucessful Registration .. Try Again Later";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
       
    }
}
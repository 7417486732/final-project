﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BUSINESS_OBJECT;
using BAL;
namespace WebApplication1
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "admin" && TextBox2.Text == "password")
            {
                Response.Redirect("Admin.aspx");
            }
            else
            {
                register_object ro = new register_object();
                register_bal cb = new register_bal();
                ro.name = TextBox1.Text;
                ro.password = TextBox2.Text;
                int str_temp = cb.user_login_process(ro);

                if (str_temp == 1)
                {
                    Session["uid"] = TextBox1.Text;
                    Session.Timeout = 1; 
                    //Redirection
                    Response.Redirect("Profile.aspx");

                }
            }
            
        }
}
}
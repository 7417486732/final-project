﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;
using BUSINESS_OBJECT;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

namespace reg
{

    public partial class Booking2 : System.Web.UI.Page
    {
        booking_object bo = new booking_object();
        register_bal ro = new register_bal();
        int num;
        int count=0;
       
           
        protected void Page_Load(object sender, EventArgs e)
        {
           
            
            TextBox2.Text = Session["rooms"].ToString();
            int n = Convert.ToInt32(TextBox2.Text);
            TextBox3.Text = Session["hotelnm"].ToString();
            TextBox5.Text = Session["Cname"].ToString();
            TextBox4.Text = Session["rentofroom"].ToString();
            int rent = Convert.ToInt32(TextBox4.Text);
            TextBox4.Text = (n * rent).ToString();
            Session["amount"] = TextBox4.Text;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //Session["Cname"] = TextBox5.Text;
            //Session["BID"] = num.ToString();
            //Session["amount"] = TextBox4.Text;
         
            Response.Redirect("Payment.aspx");       
        }

        

        protected void Button1_Click(object sender, EventArgs e)
        {
            //here we have to write the code for insert a booking and simultaneously display that
            //code in the gridview below using bind() function call
         
            if (count < 1)
            {

                Random rd = new Random();
                num = rd.Next();
                TextBox1.Text = num.ToString();
                Session["BID"] = num.ToString();
                count++;
            }
            bo.id = TextBox1.Text;
            bo.noofrooms = TextBox2.Text;
            bo.hotelname = TextBox3.Text;
            bo.amount = TextBox4.Text;
            bo.Cname = TextBox5.Text;
            Session["Cname"] = TextBox5.Text;      
          
            string msg = ro.insertbooking(bo);
            if (!msg.Equals("Success"))
            {
                //Label lb = new Label();
                //lb.Text = "Insert Succesfull";
                GridView1.DataSource = ro.searchbooking(bo);
                GridView1.DataBind();
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                {
                    //To Export all pages
                    bo.id = TextBox1.Text;
                    GridView1.DataSource = ro.searchbooking(bo);
                    GridView1.DataBind();

                    GridView1.RenderControl(hw);
                    StringReader sr = new StringReader(sw.ToString());
                    Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                    HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                    PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                    pdfDoc.Open();
                    htmlparser.Parse(sr);
                    pdfDoc.Close();

                    Response.ContentType = "application/pdf";
                    Response.AddHeader("content-disposition", "attachment;filename=Report.pdf");
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.Write(pdfDoc);
                    Response.End();
                }
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}
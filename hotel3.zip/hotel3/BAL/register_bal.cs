﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using BAL;
using DAL;
using BUSINESS_OBJECT;

namespace BAL
{
    public class register_bal
    {
        public string insertcustomer(register_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.User_Registration(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
            //finally
            //{
            //    data_object_I = null;
            //}

        }

        public int user_login_process(register_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return (int)data_object_I.User_Login(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
        }
        public string inserthotel(hotel_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Hotel_Insert(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
            //finally
            //{
            //    data_object_I = null;
            //}

        }

        public string Payments(payment_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Payments(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        public string updatehotel(hotel_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Hotel_Update(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
            //finally
            //{
            //    data_object_I = null;
            //}

        }

        public DataSet search(hotel_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Search(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //inserting booking
        public string insertbooking(booking_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.booking(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
            //finally
            //{
            //    data_object_I = null;
            //}

        }

        public DataSet searchbooking(booking_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.BookSearch(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
        }
        public string Payments_Details(paymentdetails cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Payments_Details(cs);
            }
            catch (Exception error)
            {
                throw error;
            }

        }

        public string update_balance(Updatebalance cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Update_Balance(cs);
            }
            catch (Exception error)
            {
                throw error;
            }

        }

        public DataSet showcustomer(register_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Show_Customer(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        public string cancelbooking(paymentdetails cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Cancel_Booking(cs);
            }
            catch (Exception error)
            {
                throw error;
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUSINESS_OBJECT
{
   public class booking_object
    {
        public string id { get; set; }
        public string noofrooms { get; set; }
        public string hotelname { get; set; }
        public string amount { get; set; }
        public string Cname {get; set;}

    }
}
